import { useState, useEffect } from "react";
import {
  Shield, AlertTriangle, BarChart3, Users, ClipboardList, LogOut,
  Bell, Search, ChevronDown, Plus, Eye, Edit2, Trash2, CheckCircle,
  Clock, XCircle, TrendingUp, FileText, Lock, Home, Menu, X,
  ArrowLeft, Zap, Activity, AlertCircle, CheckSquare, UserCheck,
  RefreshCw, Download, Printer, Filter, Calendar, ChevronRight,
  MoreVertical, Info, ShieldCheck, ShieldAlert, Terminal,
  MessageSquare, Radio, Settings, Database, UserX, Hash, List, Globe
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";

// ─── Types ───────────────────────────────────────────────────────────────────
type Page =
  | "login" | "dashboard" | "crises" | "crises-new" | "crises-edit"
  | "crises-detail" | "relatorios" | "relatorios-new" | "relatorios-detail"
  | "usuarios" | "usuarios-detail" | "auditoria" | "acesso-negado";

type Role = "ADMIN" | "GERENTE" | "ANALISTA" | "VISUALIZADOR";
type NivelCrise = "BAIXO" | "MEDIO" | "ALTO" | "CRITICO";
type StatusCrise = "ABERTA" | "EM_ANDAMENTO" | "RESOLVIDA" | "ENCERRADA";
type TipoAcao = "CONTENCAO" | "COMUNICACAO" | "RESOLUCAO" | "MONITORAMENTO";
type MetodoHTTP = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

interface Usuario { id: number; nome: string; email: string; perfil: Role; ativo: boolean; ultimoAcesso: string; criadoEm: string; }
interface Crise { id: number; titulo: string; descricao: string; nivel: NivelCrise; status: StatusCrise; responsavelId: number; criadoPorId: number; criadoEm: string; atualizadoEm: string; }
interface Acao { id: number; criseId: number; tipo: TipoAcao; descricao: string; usuarioId: number; criadoEm: string; }
interface Relatorio { id: number; titulo: string; criseId: number; geradoPorId: number; conteudo: string; criadoEm: string; }
interface LogAuditoria { id: number; metodo: MetodoHTTP; endpoint: string; usuarioId: number; criadoEm: string; }

// ─── Mock Data ────────────────────────────────────────────────────────────────
const USUARIOS: Usuario[] = [
  { id: 1, nome: "Maria Silva", email: "maria.silva@corp.com", perfil: "ADMIN", ativo: true, ultimoAcesso: "2026-06-22 14:32", criadoEm: "2025-01-10" },
  { id: 2, nome: "João Santos", email: "joao.santos@corp.com", perfil: "GERENTE", ativo: true, ultimoAcesso: "2026-06-22 11:15", criadoEm: "2025-02-14" },
  { id: 3, nome: "Ana Costa", email: "ana.costa@corp.com", perfil: "ANALISTA", ativo: true, ultimoAcesso: "2026-06-21 09:47", criadoEm: "2025-03-05" },
  { id: 4, nome: "Carlos Mendes", email: "carlos.mendes@corp.com", perfil: "VISUALIZADOR", ativo: false, ultimoAcesso: "2026-05-30 16:22", criadoEm: "2025-04-18" },
  { id: 5, nome: "Fernanda Lima", email: "fernanda.lima@corp.com", perfil: "ANALISTA", ativo: true, ultimoAcesso: "2026-06-22 08:55", criadoEm: "2025-05-01" },
];

const CRISES: Crise[] = [
  { id: 1, titulo: "Vazamento de dados", descricao: "Acesso não autorizado detectado nos servidores de banco de dados. Mais de 50 mil registros potencialmente comprometidos. Ação imediata necessária.", nivel: "CRITICO", status: "EM_ANDAMENTO", responsavelId: 1, criadoPorId: 2, criadoEm: "2026-06-18 09:00", atualizadoEm: "2026-06-22 14:00" },
  { id: 2, titulo: "Indisponibilidade do sistema", descricao: "Sistema de pagamentos fora do ar por mais de 2 horas. Clientes relatando falhas em transações.", nivel: "ALTO", status: "ABERTA", responsavelId: 2, criadoPorId: 1, criadoEm: "2026-06-20 14:30", atualizadoEm: "2026-06-20 14:30" },
  { id: 3, titulo: "Reclamação pública em redes sociais", descricao: "Campanha negativa viral nas redes sociais relacionada a falha no atendimento ao cliente.", nivel: "MEDIO", status: "RESOLVIDA", responsavelId: 3, criadoPorId: 1, criadoEm: "2026-06-15 10:00", atualizadoEm: "2026-06-17 16:00" },
  { id: 4, titulo: "Incêndio no datacenter secundário", descricao: "Princípio de incêndio no datacenter de São Paulo. Equipamentos de supressão acionados automaticamente.", nivel: "CRITICO", status: "ENCERRADA", responsavelId: 2, criadoPorId: 2, criadoEm: "2026-06-01 03:15", atualizadoEm: "2026-06-02 08:00" },
  { id: 5, titulo: "Fraude em contratos", descricao: "Identificação de contratos suspeitos emitidos pelo setor financeiro sem aprovação gerencial.", nivel: "ALTO", status: "EM_ANDAMENTO", responsavelId: 1, criadoPorId: 1, criadoEm: "2026-06-19 11:00", atualizadoEm: "2026-06-21 09:30" },
  { id: 6, titulo: "Falha de compliance regulatório", descricao: "Não conformidade identificada na auditoria interna trimestral.", nivel: "MEDIO", status: "ABERTA", responsavelId: 3, criadoPorId: 2, criadoEm: "2026-06-21 15:00", atualizadoEm: "2026-06-21 15:00" },
  { id: 7, titulo: "Ataque de phishing interno", descricao: "E-mails fraudulentos enviados para colaboradores simulando comunicados do RH.", nivel: "ALTO", status: "ABERTA", responsavelId: 5, criadoPorId: 1, criadoEm: "2026-06-22 08:00", atualizadoEm: "2026-06-22 08:00" },
  { id: 8, titulo: "Perda de equipamentos", descricao: "Notebooks corporativos extraviados durante transporte entre filiais.", nivel: "BAIXO", status: "RESOLVIDA", responsavelId: 3, criadoPorId: 3, criadoEm: "2026-06-10 13:00", atualizadoEm: "2026-06-12 10:00" },
];

const ACOES: Acao[] = [
  { id: 1, criseId: 1, tipo: "CONTENCAO", descricao: "Bloqueio temporário dos acessos suspeitos e revogação de tokens de sessão ativos.", usuarioId: 2, criadoEm: "2026-06-18 09:45" },
  { id: 2, criseId: 1, tipo: "COMUNICACAO", descricao: "Comunicado interno enviado à diretoria e ao conselho de segurança.", usuarioId: 1, criadoEm: "2026-06-18 11:00" },
  { id: 3, criseId: 1, tipo: "MONITORAMENTO", descricao: "Monitoramento contínuo dos logs de acesso e análise forense iniciada.", usuarioId: 3, criadoEm: "2026-06-19 08:30" },
  { id: 4, criseId: 2, tipo: "CONTENCAO", descricao: "Failover ativado para o servidor de contingência.", usuarioId: 2, criadoEm: "2026-06-20 15:00" },
  { id: 5, criseId: 3, tipo: "COMUNICACAO", descricao: "Nota de esclarecimento publicada nas redes sociais.", usuarioId: 1, criadoEm: "2026-06-15 14:00" },
  { id: 6, criseId: 3, tipo: "RESOLUCAO", descricao: "Equipe de atendimento reforçada e protocolos revisados.", usuarioId: 3, criadoEm: "2026-06-17 09:00" },
];

const RELATORIOS: Relatorio[] = [
  { id: 1, titulo: "Relatório de Incidente — Reclamação Pública", criseId: 3, geradoPorId: 1, conteudo: "Este relatório documenta o incidente de reclamação pública ocorrido em 15/06/2026. A crise foi identificada via monitoramento de redes sociais, contida com comunicado oficial e resolvida com melhoria nos processos de atendimento. Impacto estimado: médio. Lições aprendidas: necessidade de protocolo de resposta rápida em mídias sociais.", criadoEm: "2026-06-18 10:00" },
  { id: 2, titulo: "Relatório de Encerramento — Incêndio Datacenter SP", criseId: 4, geradoPorId: 2, conteudo: "Incêndio de pequena proporção contido pelos sistemas automáticos de supressão. Sem vítimas. Danos materiais limitados a 2 servidores. Backup e failover ativados. RTO alcançado: 45 minutos. RPO: 5 minutos. Ações preventivas: revisão do sistema de climatização agendada.", criadoEm: "2026-06-03 09:00" },
];

const LOGS: LogAuditoria[] = [
  { id: 1, metodo: "POST", endpoint: "/api/crises", usuarioId: 1, criadoEm: "2026-06-22 14:32" },
  { id: 2, metodo: "PATCH", endpoint: "/api/crises/1/status", usuarioId: 2, criadoEm: "2026-06-22 14:00" },
  { id: 3, metodo: "POST", endpoint: "/api/relatorios", usuarioId: 1, criadoEm: "2026-06-22 13:45" },
  { id: 4, metodo: "GET", endpoint: "/api/auditoria", usuarioId: 1, criadoEm: "2026-06-22 13:30" },
  { id: 5, metodo: "DELETE", endpoint: "/api/usuarios/4", usuarioId: 1, criadoEm: "2026-06-22 12:00" },
  { id: 6, metodo: "PUT", endpoint: "/api/crises/5", usuarioId: 2, criadoEm: "2026-06-22 11:15" },
  { id: 7, metodo: "POST", endpoint: "/api/acoes", usuarioId: 3, criadoEm: "2026-06-22 10:00" },
  { id: 8, metodo: "GET", endpoint: "/api/crises", usuarioId: 5, criadoEm: "2026-06-22 09:55" },
  { id: 9, metodo: "PATCH", endpoint: "/api/usuarios/3/perfil", usuarioId: 1, criadoEm: "2026-06-21 17:00" },
  { id: 10, metodo: "GET", endpoint: "/api/relatorios/1", usuarioId: 2, criadoEm: "2026-06-21 16:30" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────
const nivelColors: Record<NivelCrise, string> = {
  BAIXO: "bg-green-100 text-green-700 border border-green-200",
  MEDIO: "bg-yellow-100 text-yellow-700 border border-yellow-200",
  ALTO: "bg-orange-100 text-orange-700 border border-orange-200",
  CRITICO: "bg-red-100 text-red-700 border border-red-200",
};
const statusColors: Record<StatusCrise, string> = {
  ABERTA: "bg-blue-100 text-blue-700 border border-blue-200",
  EM_ANDAMENTO: "bg-yellow-100 text-yellow-700 border border-yellow-200",
  RESOLVIDA: "bg-green-100 text-green-700 border border-green-200",
  ENCERRADA: "bg-slate-100 text-slate-600 border border-slate-200",
};
const perfilColors: Record<Role, string> = {
  ADMIN: "bg-purple-100 text-purple-700 border border-purple-200",
  GERENTE: "bg-blue-100 text-blue-700 border border-blue-200",
  ANALISTA: "bg-cyan-100 text-cyan-700 border border-cyan-200",
  VISUALIZADOR: "bg-slate-100 text-slate-600 border border-slate-200",
};
const metodoColors: Record<MetodoHTTP, string> = {
  GET: "bg-blue-100 text-blue-700",
  POST: "bg-green-100 text-green-700",
  PUT: "bg-yellow-100 text-yellow-700",
  PATCH: "bg-orange-100 text-orange-700",
  DELETE: "bg-red-100 text-red-700",
};
const tipoAcaoColors: Record<TipoAcao, string> = {
  CONTENCAO: "bg-red-100 text-red-700",
  COMUNICACAO: "bg-blue-100 text-blue-700",
  RESOLUCAO: "bg-green-100 text-green-700",
  MONITORAMENTO: "bg-purple-100 text-purple-700",
};
const tipoAcaoIcons: Record<TipoAcao, React.ReactNode> = {
  CONTENCAO: <ShieldAlert size={14} />,
  COMUNICACAO: <MessageSquare size={14} />,
  RESOLUCAO: <CheckCircle size={14} />,
  MONITORAMENTO: <Radio size={14} />,
};

function getUsuario(id: number) { return USUARIOS.find(u => u.id === id); }
function getCrise(id: number) { return CRISES.find(c => c.id === id); }
function getAcoesCrise(criseId: number) { return ACOES.filter(a => a.criseId === criseId); }
function initials(nome: string) { return nome.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase(); }
function avatarColor(nome: string) {
  const colors = ["bg-blue-500", "bg-purple-500", "bg-green-500", "bg-orange-500", "bg-pink-500", "bg-teal-500"];
  return colors[nome.charCodeAt(0) % colors.length];
}

// ─── Reusable Components ──────────────────────────────────────────────────────
function Badge({ className, children }: { className?: string; children: React.ReactNode }) {
  return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold font-mono ${className}`}>{children}</span>;
}

function Btn({ variant = "primary", size = "md", onClick, children, className = "", disabled = false, type = "button" }: {
  variant?: "primary" | "secondary" | "danger" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const base = "inline-flex items-center gap-2 font-medium rounded-lg transition-all duration-150 cursor-pointer select-none";
  const sizes = { sm: "px-3 py-1.5 text-sm", md: "px-4 py-2 text-sm", lg: "px-6 py-3 text-base" };
  const variants = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 shadow-sm hover:shadow-md active:scale-95",
    secondary: "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 shadow-sm",
    danger: "bg-red-600 text-white hover:bg-red-700 shadow-sm",
    ghost: "text-slate-600 hover:bg-slate-100",
    outline: "text-blue-600 border border-blue-200 hover:bg-blue-50",
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${sizes[size]} ${variants[variant]} ${disabled ? "opacity-50 cursor-not-allowed" : ""} ${className}`}>
      {children}
    </button>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-white rounded-xl border border-slate-200 shadow-sm ${className}`}>{children}</div>;
}

function Input({ label, placeholder, type = "text", value, onChange, icon }: {
  label?: string; placeholder?: string; type?: string; value?: string; onChange?: (v: string) => void; icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-medium text-slate-700">{label}</label>}
      <div className="relative">
        {icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{icon}</span>}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange?.(e.target.value)}
          className={`w-full bg-slate-50 border border-slate-200 rounded-lg py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${icon ? "pl-10 pr-4" : "px-4"}`}
        />
      </div>
    </div>
  );
}

function Select({ label, value, onChange, options }: {
  label?: string; value?: string; onChange?: (v: string) => void; options: { value: string; label: string }[];
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-medium text-slate-700">{label}</label>}
      <select
        value={value}
        onChange={e => onChange?.(e.target.value)}
        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none cursor-pointer"
      >
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Textarea({ label, placeholder, value, onChange, rows = 4 }: {
  label?: string; placeholder?: string; value?: string; onChange?: (v: string) => void; rows?: number;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-medium text-slate-700">{label}</label>}
      <textarea
        rows={rows}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange?.(e.target.value)}
        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
      />
    </div>
  );
}

function Modal({ open, onClose, title, subtitle, children, width = "max-w-lg" }: {
  open: boolean; onClose: () => void; title: string; subtitle?: string; children: React.ReactNode; width?: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative w-full ${width} bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden`}>
        <div className="px-6 py-5 border-b border-slate-100 flex items-start justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">{title}</h3>
            {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors ml-4 mt-0.5">
            <X size={18} />
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function EmptyState({ icon, text }: { icon?: React.ReactNode; text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
        {icon || <List size={20} />}
      </div>
      <p className="text-sm text-slate-500">{text}</p>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="flex flex-col items-center justify-center py-24 gap-3">
      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      <p className="text-sm text-slate-500">Carregando informações...</p>
    </div>
  );
}

function Avatar({ nome, size = "md" }: { nome: string; size?: "sm" | "md" | "lg" | "xl" }) {
  const s = { sm: "w-7 h-7 text-xs", md: "w-9 h-9 text-sm", lg: "w-12 h-12 text-base", xl: "w-16 h-16 text-xl" };
  return (
    <div className={`${s[size]} ${avatarColor(nome)} rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0`}>
      {initials(nome)}
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const navItems = [
  { key: "dashboard", label: "Dashboard", icon: Home },
  { key: "crises", label: "Crises", icon: AlertTriangle },
  { key: "relatorios", label: "Relatórios", icon: FileText },
  { key: "usuarios", label: "Usuários", icon: Users },
  { key: "auditoria", label: "Auditoria", icon: ClipboardList },
];

function Sidebar({ currentPage, navigate, userRole, mobileOpen, onClose }: {
  currentPage: Page; navigate: (p: Page) => void; userRole: Role; mobileOpen: boolean; onClose: () => void;
}) {
  const restricted: Partial<Record<string, Role[]>> = {
    usuarios: ["ADMIN"],
    auditoria: ["ADMIN", "GERENTE"],
    relatorios: ["ADMIN", "GERENTE"],
  };

  return (
    <>
      {mobileOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={onClose} />}
      <aside className={`fixed top-0 left-0 h-full w-64 bg-[#0F172A] flex flex-col z-40 transition-transform duration-300 ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="px-5 py-5 border-b border-slate-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center flex-shrink-0">
            <Shield size={18} className="text-white" />
          </div>
          <div>
            <div className="text-white font-bold text-sm leading-tight">Gestão de Crises</div>
            <div className="text-slate-400 text-xs">Corporativas</div>
          </div>
          <button onClick={onClose} className="ml-auto text-slate-500 hover:text-slate-300 lg:hidden">
            <X size={18} />
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {navItems.map(item => {
            const allowed = !restricted[item.key] || restricted[item.key]!.includes(userRole);
            const isActive = currentPage === item.key || (item.key === "crises" && currentPage.startsWith("crises")) || (item.key === "relatorios" && currentPage.startsWith("relatorios")) || (item.key === "usuarios" && currentPage.startsWith("usuarios"));
            return (
              <button
                key={item.key}
                onClick={() => {
                  if (!allowed) navigate("acesso-negado");
                  else navigate(item.key as Page);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                  isActive
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-900/30"
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                } ${!allowed ? "opacity-50" : ""}`}
              >
                <item.icon size={16} />
                {item.label}
                {!allowed && <Lock size={12} className="ml-auto opacity-60" />}
              </button>
            );
          })}
        </nav>

        <div className="px-5 py-4 border-t border-slate-800">
          <div className="text-xs text-slate-600 font-mono">v1.0.0</div>
        </div>
      </aside>
    </>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────
function Header({ title, currentUser, onLogout, onMenuOpen, notifications = 3 }: {
  title: string; currentUser: Usuario; onLogout: () => void; onMenuOpen: () => void; notifications?: number;
}) {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 lg:px-6 flex items-center gap-4 sticky top-0 z-20">
      <button onClick={onMenuOpen} className="text-slate-500 hover:text-slate-700 lg:hidden">
        <Menu size={20} />
      </button>

      <div className="flex-1 min-w-0">
        <h1 className="text-base font-semibold text-slate-800 truncate">{title}</h1>
      </div>

      <div className="hidden md:flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 w-56">
        <Search size={14} className="text-slate-400 flex-shrink-0" />
        <input placeholder="Busca global..." className="bg-transparent text-sm text-slate-600 placeholder-slate-400 focus:outline-none w-full" />
      </div>

      <button className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-slate-50 border border-slate-200 text-slate-500">
        <Bell size={16} />
        {notifications > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{notifications}</span>
        )}
      </button>

      <div className="relative">
        <button
          onClick={() => setUserMenuOpen(!userMenuOpen)}
          className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg hover:bg-slate-50 border border-slate-200 transition-colors"
        >
          <Avatar nome={currentUser.nome} size="sm" />
          <div className="hidden md:block text-left">
            <div className="text-sm font-medium text-slate-800 leading-tight">{currentUser.nome.split(" ")[0]}</div>
            <div className="text-xs text-slate-500">{currentUser.perfil}</div>
          </div>
          <ChevronDown size={14} className="text-slate-400 hidden md:block" />
        </button>
        {userMenuOpen && (
          <div className="absolute right-0 top-full mt-2 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50">
            <div className="px-4 py-2 border-b border-slate-100">
              <div className="text-sm font-medium text-slate-800">{currentUser.nome}</div>
              <div className="text-xs text-slate-500">{currentUser.email}</div>
            </div>
            <button className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">
              <Settings size={14} /> Configurações
            </button>
            <button
              onClick={() => { setUserMenuOpen(false); onLogout(); }}
              className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50"
            >
              <LogOut size={14} /> Sair
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

// ─── Layout Wrapper ───────────────────────────────────────────────────────────
function Layout({ children, title, currentUser, currentPage, navigate, onLogout }: {
  children: React.ReactNode; title: string; currentUser: Usuario; currentPage: Page; navigate: (p: Page) => void; onLogout: () => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar currentPage={currentPage} navigate={navigate} userRole={currentUser.perfil} mobileOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col lg:ml-64 min-w-0">
        <Header title={title} currentUser={currentUser} onLogout={onLogout} onMenuOpen={() => setSidebarOpen(true)} />
        <main className="flex-1 p-4 lg:p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}

// ─── Page Header ──────────────────────────────────────────────────────────────
function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
    </div>
  );
}

// ─── LOGIN PAGE ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin }: { onLogin: (u: Usuario) => void }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setErro(false);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const user = USUARIOS.find(u => u.email === email && u.ativo);
      if (user) onLogin(user);
      else setErro(true);
    }, 800);
  };

  const demoLogins = [
    { label: "Admin", email: "maria.silva@corp.com" },
    { label: "Gerente", email: "joao.santos@corp.com" },
    { label: "Analista", email: "ana.costa@corp.com" },
  ];

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Left */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#1E40AF] relative flex-col justify-between p-10 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-20 -right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 -left-20 w-64 h-64 bg-blue-700/20 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full opacity-5">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="absolute border border-white/30 rounded-full" style={{ width: `${(i + 1) * 15}%`, height: `${(i + 1) * 15}%`, top: "50%", left: "50%", transform: "translate(-50%,-50%)" }} />
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 flex items-center justify-center shadow-xl shadow-blue-900/50">
              <Shield size={22} className="text-white" />
            </div>
            <span className="text-white font-bold text-lg tracking-tight">GCC</span>
          </div>

          <h1 className="text-4xl font-extrabold text-white leading-tight mb-4">
            Gestão de Crises<br />
            <span className="text-blue-400">Corporativas</span>
          </h1>
          <p className="text-slate-300 text-base leading-relaxed mb-10 max-w-sm">
            Monitore, responda e documente crises com segurança e agilidade em tempo real.
          </p>

          <div className="space-y-3 mb-10">
            {[
              { icon: Zap, text: "Resposta rápida a incidentes críticos" },
              { icon: Lock, text: "Controle de acesso por perfil" },
              { icon: ClipboardList, text: "Auditoria completa de ações" },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-400/30 flex items-center justify-center">
                  <Icon size={13} className="text-blue-400" />
                </div>
                <span className="text-slate-300 text-sm">{text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative space-y-2">
          {[
            { icon: AlertCircle, color: "text-red-400", bg: "bg-red-500/10 border-red-500/20", label: "Crise crítica detectada", sub: "Vazamento de dados — agora" },
            { icon: CheckCircle, color: "text-green-400", bg: "bg-green-500/10 border-green-500/20", label: "Ação registrada", sub: "Contenção aplicada — 2 min atrás" },
            { icon: FileText, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20", label: "Relatório gerado", sub: "Incidente #14 encerrado" },
          ].map(({ icon: Icon, color, bg, label, sub }) => (
            <div key={label} className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${bg} backdrop-blur-sm`}>
              <Icon size={15} className={color} />
              <div>
                <div className="text-sm font-medium text-white">{label}</div>
                <div className="text-xs text-slate-400">{sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right */}
      <div className="flex-1 flex items-center justify-center p-6 bg-[#F8FAFC]">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center">
              <Shield size={18} className="text-white" />
            </div>
            <span className="text-slate-800 font-bold text-base">Gestão de Crises Corporativas</span>
          </div>

          <Card className="p-8 shadow-xl shadow-slate-200/60">
            <div className="mb-7">
              <h2 className="text-2xl font-bold text-slate-900">Entrar no sistema</h2>
              <p className="text-sm text-slate-500 mt-1">Acesse sua conta para continuar</p>
            </div>

            <div className="space-y-4 mb-5">
              <Input label="Email" type="email" placeholder="seu@email.com" value={email} onChange={setEmail} icon={<Globe size={14} />} />
              <Input label="Senha" type="password" placeholder="••••••••" value={senha} onChange={setSenha} icon={<Lock size={14} />} />
            </div>

            <div className="flex items-center justify-between mb-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-blue-600 accent-blue-600" />
                <span className="text-sm text-slate-600">Lembrar acesso</span>
              </label>
              <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">Esqueci minha senha</button>
            </div>

            {erro && (
              <div className="flex items-center gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm mb-4">
                <AlertCircle size={14} /> Email ou senha inválidos
              </div>
            )}

            <Btn variant="primary" size="lg" onClick={handleLogin} disabled={loading} className="w-full justify-center">
              {loading ? <><div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> Entrando...</> : "Entrar"}
            </Btn>

            <div className="mt-5 pt-5 border-t border-slate-100">
              <p className="text-xs text-slate-400 mb-2 text-center">Acesso rápido (demonstração)</p>
              <div className="flex gap-2">
                {demoLogins.map(d => (
                  <button key={d.label} onClick={() => { setEmail(d.email); setSenha("demo"); setErro(false); }} className="flex-1 text-xs px-2 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors">
                    {d.label}
                  </button>
                ))}
              </div>
            </div>
          </Card>

          <p className="text-center text-xs text-slate-400 mt-6">© 2026 Gestão de Crises Corporativas</p>
        </div>
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function DashboardPage({ navigate }: { navigate: (p: Page) => void }) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 600); return () => clearTimeout(t); }, []);

  const stats = {
    total: CRISES.length,
    abertas: CRISES.filter(c => c.status === "ABERTA").length,
    emAndamento: CRISES.filter(c => c.status === "EM_ANDAMENTO").length,
    resolvidas: CRISES.filter(c => c.status === "RESOLVIDA").length,
    criticas: CRISES.filter(c => c.nivel === "CRITICO").length,
  };

  const byStatus = [
    { name: "Abertas", value: stats.abertas, color: "#3B82F6" },
    { name: "Em Andamento", value: stats.emAndamento, color: "#F59E0B" },
    { name: "Resolvidas", value: stats.resolvidas, color: "#16A34A" },
    { name: "Encerradas", value: CRISES.filter(c => c.status === "ENCERRADA").length, color: "#94A3B8" },
  ];

  const byNivel = [
    { name: "Baixo", value: CRISES.filter(c => c.nivel === "BAIXO").length, fill: "#16A34A" },
    { name: "Médio", value: CRISES.filter(c => c.nivel === "MEDIO").length, fill: "#F59E0B" },
    { name: "Alto", value: CRISES.filter(c => c.nivel === "ALTO").length, fill: "#EA580C" },
    { name: "Crítico", value: stats.criticas, fill: "#DC2626" },
  ];

  const statCards = [
    { label: "Total de crises", value: stats.total, icon: BarChart3, color: "bg-slate-100 text-slate-600", border: "border-l-slate-400" },
    { label: "Crises abertas", value: stats.abertas, icon: AlertCircle, color: "bg-blue-100 text-blue-600", border: "border-l-blue-500" },
    { label: "Em andamento", value: stats.emAndamento, icon: Activity, color: "bg-yellow-100 text-yellow-600", border: "border-l-yellow-500" },
    { label: "Resolvidas", value: stats.resolvidas, icon: CheckCircle, color: "bg-green-100 text-green-600", border: "border-l-green-500" },
    { label: "Críticas", value: stats.criticas, icon: AlertTriangle, color: "bg-red-100 text-red-600", border: "border-l-red-500" },
  ];

  if (loading) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Dashboard" subtitle="Visão geral das crises corporativas em tempo real" />

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
        {statCards.map(s => (
          <Card key={s.label} className={`p-5 border-l-4 ${s.border}`}>
            <div className={`w-9 h-9 rounded-lg ${s.color} flex items-center justify-center mb-3`}>
              <s.icon size={16} />
            </div>
            <div className="text-3xl font-bold text-slate-900 mb-0.5">{s.value}</div>
            <div className="text-xs text-slate-500 font-medium">{s.label}</div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        <Card className="p-5 xl:col-span-1">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-800">Crises por status</h3>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={byStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} innerRadius={45}>
                {byStatus.map(entry => <Cell key={entry.name} fill={entry.color} />)}
              </Pie>
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px" }} />
              <Tooltip contentStyle={{ borderRadius: "8px", border: "1px solid #E2E8F0", fontSize: "12px" }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 xl:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-800">Crises por nível de criticidade</h3>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={byNivel} barSize={40}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: "8px", border: "1px solid #E2E8F0", fontSize: "12px" }} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {byNivel.map(entry => <Cell key={entry.name} fill={entry.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card className="xl:col-span-2">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-800">Últimas crises cadastradas</h3>
            <button onClick={() => navigate("crises")} className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
              Ver todas <ChevronRight size={12} />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  {["Título", "Nível", "Status", "Responsável"].map(h => (
                    <th key={h} className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide px-5 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CRISES.slice(0, 5).map(c => (
                  <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                    <td className="px-5 py-3 font-medium text-slate-800 max-w-[160px] truncate">{c.titulo}</td>
                    <td className="px-5 py-3"><Badge className={nivelColors[c.nivel]}>{c.nivel}</Badge></td>
                    <td className="px-5 py-3"><Badge className={statusColors[c.status]}>{c.status.replace("_", " ")}</Badge></td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <Avatar nome={getUsuario(c.responsavelId)?.nome || ""} size="sm" />
                        <span className="text-slate-600 hidden sm:block">{getUsuario(c.responsavelId)?.nome.split(" ")[0]}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-3">Atalhos rápidos</h3>
            <div className="space-y-2">
              {[
                { label: "Nova crise", icon: Plus, action: "crises-new", color: "text-blue-600 bg-blue-50" },
                { label: "Registrar ação", icon: CheckSquare, action: "crises", color: "text-green-600 bg-green-50" },
                { label: "Gerar relatório", icon: FileText, action: "relatorios-new", color: "text-purple-600 bg-purple-50" },
                { label: "Ver auditoria", icon: ClipboardList, action: "auditoria", color: "text-slate-600 bg-slate-50" },
                { label: "Gerenciar usuários", icon: Users, action: "usuarios", color: "text-orange-600 bg-orange-50" },
              ].map(item => (
                <button key={item.label} onClick={() => navigate(item.action as Page)} className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all text-left">
                  <div className={`w-7 h-7 rounded-lg ${item.color} flex items-center justify-center flex-shrink-0`}>
                    <item.icon size={13} />
                  </div>
                  <span className="text-sm text-slate-700">{item.label}</span>
                  <ChevronRight size={12} className="ml-auto text-slate-400" />
                </button>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-3">Ações recentes</h3>
            <div className="space-y-3">
              {ACOES.slice(0, 3).map(a => (
                <div key={a.id} className="flex items-start gap-2.5">
                  <div className={`w-6 h-6 rounded-full ${tipoAcaoColors[a.tipo]} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                    {tipoAcaoIcons[a.tipo]}
                  </div>
                  <div className="min-w-0">
                    <Badge className={tipoAcaoColors[a.tipo] + " mb-1"}>{a.tipo}</Badge>
                    <p className="text-xs text-slate-600 truncate">{a.descricao.slice(0, 50)}...</p>
                    <p className="text-xs text-slate-400">{getUsuario(a.usuarioId)?.nome.split(" ")[0]} · {a.criadoEm.split(" ")[0]}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── CRISES LIST ──────────────────────────────────────────────────────────────
function CrisesListPage({ navigate, userRole }: { navigate: (p: Page, id?: number) => void; userRole: Role }) {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterNivel, setFilterNivel] = useState("");
  const [toDelete, setToDelete] = useState<number | null>(null);

  const filtered = CRISES.filter(c =>
    (!search || c.titulo.toLowerCase().includes(search.toLowerCase())) &&
    (!filterStatus || c.status === filterStatus) &&
    (!filterNivel || c.nivel === filterNivel)
  );

  const canCreate = ["ADMIN", "GERENTE"].includes(userRole);
  const canEdit = ["ADMIN", "GERENTE"].includes(userRole);
  const canDelete = userRole === "ADMIN";

  return (
    <div>
      <PageHeader
        title="Crises"
        subtitle="Gerencie e acompanhe todas as crises corporativas"
        actions={canCreate ? <Btn variant="primary" onClick={() => navigate("crises-new")}><Plus size={15} /> Nova crise</Btn> : undefined}
      />

      <Card className="mb-0">
        <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por título..." className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">Todos status</option>
              {["ABERTA", "EM_ANDAMENTO", "RESOLVIDA", "ENCERRADA"].map(s => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
            </select>
            <select value={filterNivel} onChange={e => setFilterNivel(e.target.value)} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">Todos níveis</option>
              {["BAIXO", "MEDIO", "ALTO", "CRITICO"].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>

        {filtered.length === 0 ? <EmptyState icon={<AlertTriangle size={20} />} text="Nenhuma crise encontrada com os filtros selecionados" /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  {["Título", "Nível", "Status", "Responsável", "Criado em", "Ações"].map(h => (
                    <th key={h} className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide px-5 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors group">
                    <td className="px-5 py-3.5">
                      <div className="font-medium text-slate-800">{c.titulo}</div>
                      <div className="text-xs text-slate-400 mt-0.5 hidden sm:block truncate max-w-[200px]">{c.descricao.slice(0, 60)}...</div>
                    </td>
                    <td className="px-5 py-3.5"><Badge className={nivelColors[c.nivel]}>{c.nivel}</Badge></td>
                    <td className="px-5 py-3.5"><Badge className={statusColors[c.status]}>{c.status.replace("_", " ")}</Badge></td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <Avatar nome={getUsuario(c.responsavelId)?.nome || ""} size="sm" />
                        <span className="text-slate-600 hidden md:block">{getUsuario(c.responsavelId)?.nome}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-slate-500 text-xs font-mono whitespace-nowrap">{c.criadoEm.split(" ")[0]}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => navigate("crises-detail", c.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-blue-100 hover:text-blue-600 flex items-center justify-center text-slate-500 transition-colors" title="Ver">
                          <Eye size={13} />
                        </button>
                        {canEdit && (
                          <button onClick={() => navigate("crises-edit", c.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-yellow-100 hover:text-yellow-600 flex items-center justify-center text-slate-500 transition-colors" title="Editar">
                            <Edit2 size={13} />
                          </button>
                        )}
                        {canDelete && (
                          <button onClick={() => setToDelete(c.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-red-100 hover:text-red-600 flex items-center justify-center text-slate-500 transition-colors" title="Excluir">
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-500">{filtered.length} registro(s) encontrado(s)</span>
        </div>
      </Card>

      <Modal open={toDelete !== null} onClose={() => setToDelete(null)} title="Confirmar exclusão" subtitle="Esta ação não pode ser desfeita">
        <p className="text-sm text-slate-600 mb-6">Tem certeza que deseja excluir esta crise? Todas as ações relacionadas também serão removidas.</p>
        <div className="flex gap-3 justify-end">
          <Btn variant="secondary" onClick={() => setToDelete(null)}>Cancelar</Btn>
          <Btn variant="danger" onClick={() => setToDelete(null)}><Trash2 size={14} /> Excluir</Btn>
        </div>
      </Modal>
    </div>
  );
}

// ─── CRISE FORM (New / Edit) ──────────────────────────────────────────────────
function CriseFormPage({ navigate, criseId }: { navigate: (p: Page) => void; criseId?: number }) {
  const crise = criseId ? getCrise(criseId) : null;
  const [titulo, setTitulo] = useState(crise?.titulo || "");
  const [descricao, setDescricao] = useState(crise?.descricao || "");
  const [nivel, setNivel] = useState(crise?.nivel || "MEDIO");
  const [responsavel, setResponsavel] = useState(String(crise?.responsavelId || "1"));

  const isEdit = !!criseId;

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("crises")} className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors">
          <ArrowLeft size={16} />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <AlertTriangle size={18} className="text-yellow-500" />
            {isEdit ? "Editar crise" : "Nova crise"}
          </h2>
          <p className="text-sm text-slate-500">{isEdit ? "Atualize as informações principais da crise" : "Registre uma nova crise corporativa"}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <Card className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="md:col-span-2">
                <Input label="Título da crise" placeholder="Ex: Vazamento de dados" value={titulo} onChange={setTitulo} />
              </div>
              <div className="md:col-span-2">
                <Textarea label="Descrição" placeholder="Descreva o ocorrido, impactos iniciais e contexto da crise." value={descricao} onChange={setDescricao} rows={5} />
              </div>
              <Select label="Nível de criticidade" value={nivel} onChange={setNivel} options={[
                { value: "BAIXO", label: "🟢 Baixo" },
                { value: "MEDIO", label: "🟡 Médio" },
                { value: "ALTO", label: "🟠 Alto" },
                { value: "CRITICO", label: "🔴 Crítico" },
              ]} />
              <Select label="Responsável" value={responsavel} onChange={setResponsavel} options={USUARIOS.filter(u => u.ativo).map(u => ({ value: String(u.id), label: u.nome }))} />
            </div>

            <div className="flex gap-3 mt-6 pt-5 border-t border-slate-100 justify-end">
              <Btn variant="secondary" onClick={() => navigate("crises")}>Cancelar</Btn>
              <Btn variant="primary" onClick={() => navigate("crises")}>
                <CheckCircle size={15} /> {isEdit ? "Salvar alterações" : "Salvar crise"}
              </Btn>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5 border-l-4 border-l-blue-500">
            <div className="flex items-center gap-2 mb-3">
              <Info size={15} className="text-blue-500" />
              <h4 className="text-sm font-semibold text-slate-800">Como funciona</h4>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Após cadastrar a crise, será possível registrar ações, acompanhar o histórico, alterar o status e gerar relatórios de encerramento.
            </p>
          </Card>

          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-3">Níveis de criticidade</h4>
            <div className="space-y-2">
              {(["BAIXO", "MEDIO", "ALTO", "CRITICO"] as NivelCrise[]).map(n => (
                <div key={n} className="flex items-center gap-2">
                  <Badge className={nivelColors[n]}>{n}</Badge>
                  <span className="text-xs text-slate-500">{{ BAIXO: "Impacto mínimo", MEDIO: "Impacto moderado", ALTO: "Impacto significativo", CRITICO: "Impacto crítico" }[n]}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── CRISE DETAIL ─────────────────────────────────────────────────────────────
function CriseDetailPage({ criseId, navigate, userRole }: { criseId: number; navigate: (p: Page, id?: number) => void; userRole: Role }) {
  const crise = getCrise(criseId)!;
  const acoes = getAcoesCrise(criseId);
  const responsavel = getUsuario(crise.responsavelId);
  const criadoPor = getUsuario(crise.criadoPorId);
  const [statusModal, setStatusModal] = useState(false);
  const [acaoModal, setAcaoModal] = useState(false);
  const [novoStatus, setNovoStatus] = useState(crise.status);
  const [tipoAcao, setTipoAcao] = useState<TipoAcao>("CONTENCAO");
  const [descAcao, setDescAcao] = useState("");

  const canEdit = ["ADMIN", "GERENTE"].includes(userRole);
  const canRegisterAction = ["ADMIN", "GERENTE", "ANALISTA"].includes(userRole);
  const canDelete = userRole === "ADMIN";

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <button onClick={() => navigate("crises")} className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100">
          <ArrowLeft size={16} />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 truncate">{crise.titulo}</h2>
            <Badge className={nivelColors[crise.nivel]}>{crise.nivel}</Badge>
            <Badge className={statusColors[crise.status]}>{crise.status.replace("_", " ")}</Badge>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {canEdit && <Btn variant="secondary" size="sm" onClick={() => navigate("crises-edit", criseId)}><Edit2 size={13} /> Editar</Btn>}
          {canEdit && <Btn variant="outline" size="sm" onClick={() => setStatusModal(true)}><RefreshCw size={13} /> Alterar status</Btn>}
          {canRegisterAction && <Btn variant="primary" size="sm" onClick={() => setAcaoModal(true)}><Plus size={13} /> Registrar ação</Btn>}
          {canDelete && <Btn variant="danger" size="sm"><Trash2 size={13} /> Excluir</Btn>}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <AlertTriangle size={15} className="text-yellow-500" /> Informações da crise
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Título</label>
                <p className="text-slate-800 font-medium mt-1">{crise.titulo}</p>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Descrição</label>
                <p className="text-slate-600 text-sm leading-relaxed mt-1">{crise.descricao}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Nível</label>
                  <div className="mt-1"><Badge className={nivelColors[crise.nivel]}>{crise.nivel}</Badge></div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Status</label>
                  <div className="mt-1"><Badge className={statusColors[crise.status]}>{crise.status.replace("_", " ")}</Badge></div>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-sm font-semibold text-slate-800 mb-5 flex items-center gap-2">
              <Activity size={15} className="text-blue-500" /> Histórico de ações
            </h3>
            {acoes.length === 0 ? (
              <EmptyState icon={<Activity size={18} />} text="Nenhuma ação registrada nesta crise" />
            ) : (
              <div className="relative">
                <div className="absolute left-[18px] top-0 bottom-0 w-px bg-slate-100" />
                <div className="space-y-5">
                  {acoes.map((a, i) => (
                    <div key={a.id} className="flex gap-4 relative">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 z-10 ${tipoAcaoColors[a.tipo]}`}>
                        {tipoAcaoIcons[a.tipo]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <Badge className={tipoAcaoColors[a.tipo]}>{a.tipo}</Badge>
                          <span className="text-xs text-slate-400 font-mono">{a.criadoEm}</span>
                        </div>
                        <Card className="p-3 border-slate-100">
                          <p className="text-sm text-slate-700">{a.descricao}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Avatar nome={getUsuario(a.usuarioId)?.nome || ""} size="sm" />
                            <span className="text-xs text-slate-500">{getUsuario(a.usuarioId)?.nome}</span>
                          </div>
                        </Card>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <UserCheck size={14} className="text-slate-500" /> Responsável
            </h3>
            <div className="flex items-center gap-3 mb-4">
              <Avatar nome={responsavel?.nome || ""} size="lg" />
              <div>
                <div className="font-semibold text-slate-800">{responsavel?.nome}</div>
                <div className="text-xs text-slate-500">{responsavel?.email}</div>
                <Badge className={`${perfilColors[responsavel?.perfil || "VISUALIZADOR"]} mt-1`}>{responsavel?.perfil}</Badge>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Metadados</h3>
            <div className="space-y-3">
              {[
                { label: "Criado por", value: criadoPor?.nome },
                { label: "Criado em", value: crise.criadoEm, mono: true },
                { label: "Atualizado em", value: crise.atualizadoEm, mono: true },
              ].map(({ label, value, mono }) => (
                <div key={label}>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{label}</span>
                  <p className={`text-sm text-slate-700 mt-0.5 ${mono ? "font-mono" : ""}`}>{value}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Status Modal */}
      <Modal open={statusModal} onClose={() => setStatusModal(false)} title="Alterar status da crise" subtitle="Selecione o novo status para a crise">
        <Select label="Novo status" value={novoStatus} onChange={v => setNovoStatus(v as StatusCrise)} options={[
          { value: "ABERTA", label: "Aberta" },
          { value: "EM_ANDAMENTO", label: "Em andamento" },
          { value: "RESOLVIDA", label: "Resolvida" },
          { value: "ENCERRADA", label: "Encerrada" },
        ]} />
        <div className="flex items-start gap-2 px-3 py-2.5 bg-yellow-50 border border-yellow-200 rounded-lg text-yellow-700 text-xs mt-4 mb-5">
          <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
          Crises encerradas não podem voltar para abertas.
        </div>
        <div className="flex gap-3 justify-end">
          <Btn variant="secondary" onClick={() => setStatusModal(false)}>Cancelar</Btn>
          <Btn variant="primary" onClick={() => setStatusModal(false)}><CheckCircle size={14} /> Confirmar alteração</Btn>
        </div>
      </Modal>

      {/* Action Modal */}
      <Modal open={acaoModal} onClose={() => setAcaoModal(false)} title="Registrar ação" subtitle="Documente uma ação tomada nesta crise">
        <div className="space-y-4">
          <Select label="Tipo da ação" value={tipoAcao} onChange={v => setTipoAcao(v as TipoAcao)} options={[
            { value: "CONTENCAO", label: "🛡️ Contenção" },
            { value: "COMUNICACAO", label: "💬 Comunicação" },
            { value: "RESOLUCAO", label: "✅ Resolução" },
            { value: "MONITORAMENTO", label: "📡 Monitoramento" },
          ]} />
          <Textarea label="Descrição" placeholder="Descreva detalhadamente a ação realizada..." value={descAcao} onChange={setDescAcao} rows={4} />
          <div className="flex items-start gap-2 px-3 py-2.5 bg-blue-50 border border-blue-200 rounded-lg text-blue-700 text-xs">
            <Info size={13} className="flex-shrink-0 mt-0.5" />
            Ações só podem ser registradas em crises abertas ou em andamento.
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-5">
          <Btn variant="secondary" onClick={() => setAcaoModal(false)}>Cancelar</Btn>
          <Btn variant="primary" onClick={() => setAcaoModal(false)}><Plus size={14} /> Registrar ação</Btn>
        </div>
      </Modal>
    </div>
  );
}

// ─── REPORTS LIST ─────────────────────────────────────────────────────────────
function RelatoriosListPage({ navigate }: { navigate: (p: Page, id?: number) => void }) {
  const [search, setSearch] = useState("");
  const filtered = RELATORIOS.filter(r => !search || r.titulo.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHeader
        title="Relatórios"
        subtitle="Consulte e gere relatórios de incidentes"
        actions={<Btn variant="primary" onClick={() => navigate("relatorios-new")}><Plus size={15} /> Novo relatório</Btn>}
      />
      <Card>
        <div className="px-5 py-4 border-b border-slate-100 flex gap-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar relatório..." className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
        </div>
        {filtered.length === 0 ? <EmptyState icon={<FileText size={20} />} text="Nenhum relatório encontrado" /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  {["Título", "Crise relacionada", "Gerado por", "Data", "Ações"].map(h => (
                    <th key={h} className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide px-5 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => {
                  const crise = getCrise(r.criseId);
                  const gerador = getUsuario(r.geradoPorId);
                  return (
                    <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0">
                            <FileText size={13} className="text-purple-600" />
                          </div>
                          <span className="font-medium text-slate-800">{r.titulo}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <Badge className={nivelColors[crise?.nivel || "BAIXO"]}>{crise?.nivel}</Badge>
                          <span className="text-slate-600 text-xs">{crise?.titulo}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <Avatar nome={gerador?.nome || ""} size="sm" />
                          <span className="text-slate-600">{gerador?.nome}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{r.criadoEm.split(" ")[0]}</td>
                      <td className="px-5 py-3.5">
                        <button onClick={() => navigate("relatorios-detail", r.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-blue-100 hover:text-blue-600 flex items-center justify-center text-slate-500 transition-colors" title="Visualizar">
                          <Eye size={13} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

// ─── NEW REPORT ───────────────────────────────────────────────────────────────
function NovoRelatorioPage({ navigate }: { navigate: (p: Page) => void }) {
  const [titulo, setTitulo] = useState("");
  const [criseId, setCriseId] = useState("");
  const [conteudo, setConteudo] = useState("");
  const elegiveisParaRelatorio = CRISES.filter(c => ["RESOLVIDA", "ENCERRADA"].includes(c.status));

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("relatorios")} className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100">
          <ArrowLeft size={16} />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900">Gerar relatório</h2>
          <p className="text-sm text-slate-500">Crie um relatório para uma crise resolvida ou encerrada</p>
        </div>
      </div>
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card className="xl:col-span-2 p-6">
          <div className="space-y-5">
            <Input label="Título do relatório" placeholder="Ex: Relatório de Incidente — Vazamento de Dados" value={titulo} onChange={setTitulo} />
            <Select label="Crise relacionada" value={criseId} onChange={setCriseId} options={[
              { value: "", label: "Selecione uma crise..." },
              ...elegiveisParaRelatorio.map(c => ({ value: String(c.id), label: `${c.titulo} (${c.status})` }))
            ]} />
            <Textarea label="Conteúdo do relatório" placeholder="Descreva o resumo executivo, linha do tempo, impactos, ações tomadas, lições aprendidas e recomendações..." value={conteudo} onChange={setConteudo} rows={12} />
          </div>
          <div className="flex gap-3 justify-end mt-6 pt-5 border-t border-slate-100">
            <Btn variant="secondary" onClick={() => navigate("relatorios")}>Cancelar</Btn>
            <Btn variant="primary" onClick={() => navigate("relatorios")}><FileText size={14} /> Gerar relatório</Btn>
          </div>
        </Card>
        <div className="space-y-4">
          <Card className="p-5 border-l-4 border-l-purple-500">
            <div className="flex items-center gap-2 mb-2">
              <Info size={14} className="text-purple-500" />
              <h4 className="text-sm font-semibold text-slate-800">Restrição de acesso</h4>
            </div>
            <p className="text-sm text-slate-600">Relatórios só podem ser gerados para crises com status <strong>Resolvida</strong> ou <strong>Encerrada</strong>.</p>
          </Card>
          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-3">Crises disponíveis ({elegiveisParaRelatorio.length})</h4>
            <div className="space-y-2">
              {elegiveisParaRelatorio.map(c => (
                <div key={c.id} className="flex items-center gap-2 py-2 border-b border-slate-50 last:border-0">
                  <Badge className={statusColors[c.status]}>{c.status}</Badge>
                  <span className="text-xs text-slate-600 truncate">{c.titulo}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── REPORT DETAIL ────────────────────────────────────────────────────────────
function RelatorioDetailPage({ relatorioId, navigate }: { relatorioId: number; navigate: (p: Page) => void }) {
  const relatorio = RELATORIOS.find(r => r.id === relatorioId)!;
  const crise = getCrise(relatorio.criseId);
  const gerador = getUsuario(relatorio.geradoPorId);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("relatorios")} className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Detalhe do relatório</h2>
          </div>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" size="sm"><Printer size={14} /> Imprimir</Btn>
          <Btn variant="outline" size="sm"><Download size={14} /> Exportar PDF</Btn>
        </div>
      </div>

      <div className="max-w-3xl mx-auto">
        <Card className="overflow-hidden">
          <div className="bg-gradient-to-r from-[#0F172A] to-[#1E40AF] px-8 py-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <Shield size={20} className="text-white" />
              </div>
              <div>
                <div className="text-white font-bold">Gestão de Crises Corporativas</div>
                <div className="text-blue-200 text-xs">Relatório Oficial de Incidente</div>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-white">{relatorio.titulo}</h1>
          </div>

          <div className="p-8">
            <div className="grid grid-cols-2 gap-6 mb-8 pb-8 border-b border-slate-100">
              {[
                { label: "Crise relacionada", value: crise?.titulo, badge: crise ? <Badge className={nivelColors[crise.nivel]}>{crise.nivel}</Badge> : null },
                { label: "Gerado por", value: gerador?.nome },
                { label: "Data de geração", value: relatorio.criadoEm, mono: true },
                { label: "Status da crise", value: null, badge: crise ? <Badge className={statusColors[crise.status]}>{crise.status.replace("_", " ")}</Badge> : null },
              ].map(({ label, value, mono, badge }) => (
                <div key={label}>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{label}</label>
                  <div className="mt-1">
                    {value && <p className={`text-slate-800 font-medium ${mono ? "font-mono text-sm" : ""}`}>{value}</p>}
                    {badge}
                  </div>
                </div>
              ))}
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-800 uppercase tracking-wide mb-3">Conteúdo</h3>
              <div className="bg-slate-50 rounded-xl p-6 text-sm text-slate-700 leading-relaxed whitespace-pre-wrap border border-slate-100">
                {relatorio.conteudo}
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span>Documento gerado pelo sistema GCC v1.0</span>
              <span className="font-mono">{relatorio.criadoEm}</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── USERS LIST ───────────────────────────────────────────────────────────────
function UsuariosListPage({ navigate }: { navigate: (p: Page, id?: number) => void }) {
  const [search, setSearch] = useState("");
  const [filterPerfil, setFilterPerfil] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [newUserModal, setNewUserModal] = useState(false);
  const [editUserId, setEditUserId] = useState<number | null>(null);
  const [deactivateId, setDeactivateId] = useState<number | null>(null);

  const filtered = USUARIOS.filter(u =>
    (!search || u.nome.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())) &&
    (!filterPerfil || u.perfil === filterPerfil) &&
    (!filterStatus || (filterStatus === "ativo" ? u.ativo : !u.ativo))
  );

  return (
    <div>
      <PageHeader
        title="Usuários"
        subtitle="Gerencie usuários, perfis e permissões do sistema"
        actions={<Btn variant="primary" onClick={() => setNewUserModal(true)}><Plus size={15} /> Novo usuário</Btn>}
      />

      <Card>
        <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nome ou email..." className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            <select value={filterPerfil} onChange={e => setFilterPerfil(e.target.value)} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">Todos perfis</option>
              {["ADMIN", "GERENTE", "ANALISTA", "VISUALIZADOR"].map(p => <option key={p} value={p}>{p}</option>)}
            </select>
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">Todos status</option>
              <option value="ativo">Ativo</option>
              <option value="inativo">Inativo</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Usuário", "Email", "Perfil", "Status", "Último acesso", "Ações"].map(h => (
                  <th key={h} className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide px-5 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <Avatar nome={u.nome} size="md" />
                      <span className="font-medium text-slate-800">{u.nome}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{u.email}</td>
                  <td className="px-5 py-3.5"><Badge className={perfilColors[u.perfil]}>{u.perfil}</Badge></td>
                  <td className="px-5 py-3.5">
                    <Badge className={u.ativo ? "bg-green-100 text-green-700 border border-green-200" : "bg-slate-100 text-slate-500 border border-slate-200"}>
                      {u.ativo ? "Ativo" : "Inativo"}
                    </Badge>
                  </td>
                  <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{u.ultimoAcesso}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => navigate("usuarios-detail", u.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-blue-100 hover:text-blue-600 flex items-center justify-center text-slate-500 transition-colors" title="Ver detalhes">
                        <Eye size={13} />
                      </button>
                      <button onClick={() => setEditUserId(u.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-yellow-100 hover:text-yellow-600 flex items-center justify-center text-slate-500 transition-colors" title="Editar">
                        <Edit2 size={13} />
                      </button>
                      {u.ativo && (
                        <button onClick={() => setDeactivateId(u.id)} className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-red-100 hover:text-red-600 flex items-center justify-center text-slate-500 transition-colors" title="Desativar">
                          <UserX size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-slate-100">
          <span className="text-xs text-slate-500">{filtered.length} usuário(s) encontrado(s)</span>
        </div>
      </Card>

      {/* New User Modal */}
      <Modal open={newUserModal} onClose={() => setNewUserModal(false)} title="Novo usuário" subtitle="Preencha os dados do novo usuário">
        <div className="space-y-4">
          <Input label="Nome completo" placeholder="Ex: João da Silva" />
          <Input label="Email" type="email" placeholder="joao@empresa.com" />
          <Input label="Senha" type="password" placeholder="Mínimo 8 caracteres" />
          <Select label="Perfil" options={[
            { value: "ADMIN", label: "Admin" },
            { value: "GERENTE", label: "Gerente" },
            { value: "ANALISTA", label: "Analista" },
            { value: "VISUALIZADOR", label: "Visualizador" },
          ]} />
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-300 accent-blue-600" />
            <span className="text-sm text-slate-700">Usuário ativo</span>
          </label>
          <div className="flex items-start gap-2 px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-600 text-xs">
            <Lock size={12} className="flex-shrink-0 mt-0.5" />
            A senha será armazenada de forma segura pelo sistema.
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-5">
          <Btn variant="secondary" onClick={() => setNewUserModal(false)}>Cancelar</Btn>
          <Btn variant="primary" onClick={() => setNewUserModal(false)}><Plus size={14} /> Salvar usuário</Btn>
        </div>
      </Modal>

      {/* Edit User Modal */}
      {editUserId !== null && (() => {
        const u = getUsuario(editUserId)!;
        return (
          <Modal open={true} onClose={() => setEditUserId(null)} title="Editar usuário" subtitle={`Editando: ${u.nome}`}>
            <div className="space-y-4">
              <Input label="Nome completo" value={u.nome} />
              <Input label="Email" type="email" value={u.email} />
              <Select label="Perfil" value={u.perfil} options={[
                { value: "ADMIN", label: "Admin" },
                { value: "GERENTE", label: "Gerente" },
                { value: "ANALISTA", label: "Analista" },
                { value: "VISUALIZADOR", label: "Visualizador" },
              ]} />
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked={u.ativo} className="w-4 h-4 rounded border-slate-300 accent-blue-600" />
                <span className="text-sm text-slate-700">Usuário ativo</span>
              </label>
            </div>
            <div className="flex gap-3 justify-end mt-5">
              <Btn variant="secondary" onClick={() => setEditUserId(null)}>Cancelar</Btn>
              <Btn variant="primary" onClick={() => setEditUserId(null)}><CheckCircle size={14} /> Salvar alterações</Btn>
            </div>
          </Modal>
        );
      })()}

      {/* Deactivate Modal */}
      <Modal open={deactivateId !== null} onClose={() => setDeactivateId(null)} title="Desativar usuário" subtitle="Confirme a ação">
        <p className="text-sm text-slate-600 mb-6">
          Tem certeza que deseja desativar <strong>{getUsuario(deactivateId || 0)?.nome}</strong>? O usuário perderá acesso ao sistema imediatamente.
        </p>
        <div className="flex gap-3 justify-end">
          <Btn variant="secondary" onClick={() => setDeactivateId(null)}>Cancelar</Btn>
          <Btn variant="danger" onClick={() => setDeactivateId(null)}><UserX size={14} /> Desativar usuário</Btn>
        </div>
      </Modal>
    </div>
  );
}

// ─── USER DETAIL ──────────────────────────────────────────────────────────────
function UsuarioDetailPage({ usuarioId, navigate }: { usuarioId: number; navigate: (p: Page) => void }) {
  const u = getUsuario(usuarioId)!;
  const permsMap: Record<Role, { label: string; allowed: boolean }[]> = {
    ADMIN: [
      { label: "Visualizar crises", allowed: true },
      { label: "Cadastrar crises", allowed: true },
      { label: "Editar crises", allowed: true },
      { label: "Gerar relatórios", allowed: true },
      { label: "Gerenciar usuários", allowed: true },
      { label: "Ver auditoria", allowed: true },
    ],
    GERENTE: [
      { label: "Visualizar crises", allowed: true },
      { label: "Cadastrar crises", allowed: true },
      { label: "Editar crises", allowed: true },
      { label: "Gerar relatórios", allowed: true },
      { label: "Gerenciar usuários", allowed: false },
      { label: "Ver auditoria", allowed: true },
    ],
    ANALISTA: [
      { label: "Visualizar crises", allowed: true },
      { label: "Cadastrar crises", allowed: false },
      { label: "Editar crises", allowed: false },
      { label: "Gerar relatórios", allowed: false },
      { label: "Gerenciar usuários", allowed: false },
      { label: "Ver auditoria", allowed: false },
    ],
    VISUALIZADOR: [
      { label: "Visualizar crises", allowed: true },
      { label: "Cadastrar crises", allowed: false },
      { label: "Editar crises", allowed: false },
      { label: "Gerar relatórios", allowed: false },
      { label: "Gerenciar usuários", allowed: false },
      { label: "Ver auditoria", allowed: false },
    ],
  };

  const crisesVinculadas = CRISES.filter(c => c.responsavelId === u.id || c.criadoPorId === u.id);
  const acoesUsuario = ACOES.filter(a => a.usuarioId === u.id);
  const logsUsuario = LOGS.filter(l => l.usuarioId === u.id).slice(0, 5);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("usuarios")} className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Vistoria do usuário</h2>
            <p className="text-sm text-slate-500">Visualize dados, perfil, status e atividades</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" size="sm"><Edit2 size={13} /> Editar usuário</Btn>
          {u.ativo && <Btn variant="danger" size="sm"><UserX size={13} /> Desativar</Btn>}
        </div>
      </div>

      {/* User Profile Card */}
      <Card className="p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <Avatar nome={u.nome} size="xl" />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-3 mb-2">
              <h3 className="text-xl font-bold text-slate-900">{u.nome}</h3>
              <Badge className={perfilColors[u.perfil]}>{u.perfil}</Badge>
              <Badge className={u.ativo ? "bg-green-100 text-green-700 border border-green-200" : "bg-slate-100 text-slate-500 border border-slate-200"}>
                {u.ativo ? "● Ativo" : "● Inativo"}
              </Badge>
            </div>
            <p className="text-slate-500 text-sm font-mono">{u.email}</p>
          </div>
          <div className="text-right hidden md:block">
            <div className="text-xs text-slate-400 mb-1">Último acesso</div>
            <div className="text-sm font-mono text-slate-600">{u.ultimoAcesso}</div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="space-y-5">
          {/* User data */}
          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <UserCheck size={14} className="text-blue-500" /> Dados do usuário
            </h4>
            <div className="space-y-3">
              {[
                { label: "Nome", value: u.nome },
                { label: "Email", value: u.email, mono: true },
                { label: "Perfil", value: u.perfil },
                { label: "Status", value: u.ativo ? "Ativo" : "Inativo" },
                { label: "Cadastrado em", value: u.criadoEm, mono: true },
              ].map(({ label, value, mono }) => (
                <div key={label} className="flex items-start justify-between gap-2">
                  <span className="text-xs text-slate-400 min-w-[80px]">{label}</span>
                  <span className={`text-sm text-slate-700 font-medium text-right ${mono ? "font-mono text-xs" : ""}`}>{value}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Permissions */}
          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <ShieldCheck size={14} className="text-purple-500" /> Permissões do perfil
            </h4>
            <div className="space-y-2">
              {permsMap[u.perfil].map(p => (
                <div key={p.label} className="flex items-center justify-between">
                  <span className="text-xs text-slate-600">{p.label}</span>
                  {p.allowed
                    ? <CheckCircle size={14} className="text-green-500" />
                    : <XCircle size={14} className="text-slate-300" />
                  }
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-5">
          {/* Recent activity */}
          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Terminal size={14} className="text-slate-500" /> Atividades recentes
            </h4>
            {logsUsuario.length === 0 ? <EmptyState text="Sem atividade registrada" /> : (
              <div className="space-y-2">
                {logsUsuario.map(l => (
                  <div key={l.id} className="flex items-center gap-2 py-2 border-b border-slate-50 last:border-0">
                    <Badge className={metodoColors[l.metodo]}>{l.metodo}</Badge>
                    <span className="text-xs font-mono text-slate-600 flex-1 truncate">{l.endpoint}</span>
                    <span className="text-xs text-slate-400 whitespace-nowrap">{l.criadoEm.split(" ")[1]}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Actions */}
          <Card className="p-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Activity size={14} className="text-green-500" /> Últimas ações registradas
            </h4>
            {acoesUsuario.length === 0 ? <EmptyState text="Sem ações registradas" /> : (
              <div className="space-y-2">
                {acoesUsuario.slice(0, 3).map(a => {
                  const crise = getCrise(a.criseId);
                  return (
                    <div key={a.id} className="flex items-start gap-2 py-2 border-b border-slate-50 last:border-0">
                      <Badge className={tipoAcaoColors[a.tipo]}>{a.tipo}</Badge>
                      <div className="min-w-0">
                        <p className="text-xs text-slate-600 truncate">{a.descricao.slice(0, 45)}...</p>
                        <p className="text-xs text-slate-400">{crise?.titulo}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Linked crises */}
        <Card className="p-5">
          <h4 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AlertTriangle size={14} className="text-yellow-500" /> Crises vinculadas ({crisesVinculadas.length})
          </h4>
          {crisesVinculadas.length === 0 ? <EmptyState text="Sem crises vinculadas" /> : (
            <div className="space-y-3">
              {crisesVinculadas.map(c => (
                <div key={c.id} className="p-3 rounded-lg border border-slate-100 bg-slate-50">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="text-sm font-medium text-slate-800 leading-tight">{c.titulo}</span>
                    <Badge className={nivelColors[c.nivel]}>{c.nivel}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={statusColors[c.status]}>{c.status.replace("_", " ")}</Badge>
                    <span className="text-xs text-slate-400">
                      {c.responsavelId === u.id ? "Responsável" : "Criou"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─── AUDIT PAGE ───────────────────────────────────────────────────────────────
function AuditoriaPage() {
  const [search, setSearch] = useState("");
  const [filterMetodo, setFilterMetodo] = useState("");

  const filtered = LOGS.filter(l =>
    (!search || l.endpoint.includes(search) || getUsuario(l.usuarioId)?.nome.toLowerCase().includes(search.toLowerCase())) &&
    (!filterMetodo || l.metodo === filterMetodo)
  );

  const summaryCards = [
    { label: "Total de logs", value: LOGS.length, icon: Database, color: "bg-slate-100 text-slate-600" },
    { label: "Ações hoje", value: LOGS.filter(l => l.criadoEm.startsWith("2026-06-22")).length, icon: Activity, color: "bg-blue-100 text-blue-600" },
    { label: "Usuários ativos", value: USUARIOS.filter(u => u.ativo).length, icon: Users, color: "bg-green-100 text-green-600" },
    { label: "Operações críticas", value: LOGS.filter(l => ["DELETE", "PATCH"].includes(l.metodo)).length, icon: AlertTriangle, color: "bg-red-100 text-red-600" },
  ];

  return (
    <div>
      <PageHeader title="Auditoria" subtitle="Consulte os registros de ações realizadas no sistema" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {summaryCards.map(s => (
          <Card key={s.label} className="p-4">
            <div className={`w-8 h-8 rounded-lg ${s.color} flex items-center justify-center mb-2`}>
              <s.icon size={14} />
            </div>
            <div className="text-2xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs text-slate-500">{s.label}</div>
          </Card>
        ))}
      </div>

      <Card>
        <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por endpoint ou usuário..." className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            <select value={filterMetodo} onChange={e => setFilterMetodo(e.target.value)} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">Todos métodos</option>
              {(["GET", "POST", "PUT", "PATCH", "DELETE"] as MetodoHTTP[]).map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Método", "Endpoint", "Usuário", "Data e hora", ""].map(h => (
                  <th key={h} className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide px-5 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(l => {
                const user = getUsuario(l.usuarioId);
                return (
                  <tr key={l.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                    <td className="px-5 py-3.5">
                      <Badge className={`${metodoColors[l.metodo]} font-mono`}>{l.metodo}</Badge>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="font-mono text-xs text-slate-700 bg-slate-100 px-2 py-1 rounded">{l.endpoint}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <Avatar nome={user?.nome || "?"} size="sm" />
                        <div>
                          <div className="text-slate-700 text-sm">{user?.nome}</div>
                          <div className="text-slate-400 text-xs">{user?.perfil}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-slate-500 text-xs font-mono whitespace-nowrap">{l.criadoEm}</td>
                    <td className="px-5 py-3.5">
                      <button className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-blue-100 hover:text-blue-600 flex items-center justify-center text-slate-500 transition-colors">
                        <Eye size={13} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-slate-100">
          <span className="text-xs text-slate-500">{filtered.length} registro(s)</span>
        </div>
      </Card>
    </div>
  );
}

// ─── ACCESS DENIED ────────────────────────────────────────────────────────────
function AcessoNegadoPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
      <div className="w-20 h-20 rounded-2xl bg-red-100 flex items-center justify-center mb-5">
        <Lock size={32} className="text-red-500" />
      </div>
      <h2 className="text-2xl font-bold text-slate-900 mb-2">Acesso negado</h2>
      <p className="text-slate-500 max-w-sm mb-6">Você não possui permissão para acessar esta área. Entre em contato com um administrador se acredita que isso é um erro.</p>
      <Btn variant="primary" onClick={() => navigate("dashboard")}>
        <Home size={15} /> Voltar ao dashboard
      </Btn>
    </div>
  );
}

// ─── PAGE TITLES ──────────────────────────────────────────────────────────────
function getPageTitle(page: Page, criseId?: number, relatorioId?: number, usuarioId?: number): string {
  const titles: Partial<Record<Page, string>> = {
    dashboard: "Dashboard",
    crises: "Crises",
    "crises-new": "Nova Crise",
    "crises-edit": "Editar Crise",
    "crises-detail": getCrise(criseId || 0)?.titulo || "Detalhe da Crise",
    relatorios: "Relatórios",
    "relatorios-new": "Gerar Relatório",
    "relatorios-detail": "Detalhe do Relatório",
    usuarios: "Usuários",
    "usuarios-detail": getUsuario(usuarioId || 0)?.nome || "Vistoria do Usuário",
    auditoria: "Auditoria",
    "acesso-negado": "Acesso Negado",
  };
  return titles[page] || "GCC";
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState<Usuario | null>(null);
  const [page, setPage] = useState<Page>("login");
  const [selectedCriseId, setSelectedCriseId] = useState<number>(1);
  const [selectedRelatorioId, setSelectedRelatorioId] = useState<number>(1);
  const [selectedUsuarioId, setSelectedUsuarioId] = useState<number>(1);

  const navigate = (p: Page, id?: number) => {
    if (p === "crises-detail" || p === "crises-edit") setSelectedCriseId(id || 1);
    if (p === "relatorios-detail") setSelectedRelatorioId(id || 1);
    if (p === "usuarios-detail") setSelectedUsuarioId(id || 1);
    setPage(p);
    window.scrollTo(0, 0);
  };

  const handleLogin = (user: Usuario) => {
    setCurrentUser(user);
    setPage("dashboard");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setPage("login");
  };

  if (!currentUser || page === "login") {
    return <LoginPage onLogin={handleLogin} />;
  }

  const title = getPageTitle(page, selectedCriseId, selectedRelatorioId, selectedUsuarioId);

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <DashboardPage navigate={navigate} />;
      case "crises": return <CrisesListPage navigate={navigate} userRole={currentUser.perfil} />;
      case "crises-new": return <CriseFormPage navigate={navigate} />;
      case "crises-edit": return <CriseFormPage navigate={navigate} criseId={selectedCriseId} />;
      case "crises-detail": return <CriseDetailPage criseId={selectedCriseId} navigate={navigate} userRole={currentUser.perfil} />;
      case "relatorios": return <RelatoriosListPage navigate={navigate} />;
      case "relatorios-new": return <NovoRelatorioPage navigate={navigate} />;
      case "relatorios-detail": return <RelatorioDetailPage relatorioId={selectedRelatorioId} navigate={navigate} />;
      case "usuarios": return <UsuariosListPage navigate={navigate} />;
      case "usuarios-detail": return <UsuarioDetailPage usuarioId={selectedUsuarioId} navigate={navigate} />;
      case "auditoria": return <AuditoriaPage />;
      case "acesso-negado": return <AcessoNegadoPage navigate={navigate} />;
      default: return <DashboardPage navigate={navigate} />;
    }
  };

  return (
    <Layout title={title} currentUser={currentUser} currentPage={page} navigate={navigate} onLogout={handleLogout}>
      {renderPage()}
    </Layout>
  );
}
