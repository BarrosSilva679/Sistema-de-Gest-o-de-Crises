
  # Gestão de Crises Corporativas

  This is a code bundle for Gestão de Crises Corporativas. The original project is available at https://www.figma.com/design/MsbaGeeeMBgv6vE76gv3hY/Gest%C3%A3o-de-Crises-Corporativas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  